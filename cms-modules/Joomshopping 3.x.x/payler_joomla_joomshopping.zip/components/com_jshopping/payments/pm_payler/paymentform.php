<?php
/*
* @package JoomShopping for Joomla!
* @subpackage payment
* @author Payler LLC
* @copyright Copyright (C) 2014 Payler LLC. All rights reserved.
* @license GNU General Public License version 2 or later
*/

//защита от прямого доступа
defined('_JEXEC') or die(); ?>
<script type="text/javascript">
	function check_pm_payler() {
		jQuery('#payment_form').submit();
	}
</script>